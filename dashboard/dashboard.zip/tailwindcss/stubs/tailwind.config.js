// /** @type {import('tailwindcss').Config} */
// export default __CONFIG__
/** @type {import('tailwindcss').Config} */
export default {
    content: ["./src/**/*.{js,jsx,ts,tsx,html}"], // Ensure Tailwind scans your project files
    theme: {
      extend: {},
    },
    plugins: [],
  };
  