import { cloneDeep } from '../util/cloneDeep'
import defaultConfig from '../../stubs/config.full'

export default cloneDeep(defaultConfig)
