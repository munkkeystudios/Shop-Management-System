#!/usr/bin/env node

module.exports = require('./cli/index')
